def main():
    print('Hello There!')
    name = input('What is your name?')
    print('Nice to meet you,', name)

if __name__ == "__main__":
    main()