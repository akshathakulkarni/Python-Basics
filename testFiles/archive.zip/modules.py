# import math module to use pre-built functions for performing mathematical calculations.

import math

print("The square root of 16 is ", math.sqrt(16))

print('Pi is ', math.pi)

